﻿The idea for this plugin is taken from:
http://sdrsharp.com/index.php/a-simple-and-cheap-ads-b-receiver-using-rtl-sdr

ADSB# is a standalone program to receive ADS-B signals and my ADS-B plugin does the same but from within SDR#.

ADSBScope is a software that can be used to display the ADS-B signals. It is compatible with both (plugin an ADSB#).
http://www.sprut.de/electronic/pic/projekte/adsb/adsb_en.html#pc

http://www.sprut.de/electronic/pic/projekte/adsb/adsb_fix.zip


Implementation
Bit decoder is taken and modified a bit from ADSB# which is released under MIT license.
ADSBSharp (ADSB#) is copyright (c) 2012 by Youssef Touil and Ian Gilmour, http://sdrsharp.com

Also the TCP connection to the ADS-B hub is taken from ADSB# to make it compatible.

I've also added a 1-Bit error recovery by bruteforce like the one used in Salvatore Sanfilippo C
version (see https://github.com/antirez/dump1090/blob/master/dump1090.c)


INSTALL
	- close SDRSharp if running
	- copy the SDRSharp.ADSBPlugin.dll to your SDR# directory
	- add 
		<add key="ADSB" value="SDRSharp.ADSBPlugin.ADSBPlugin,SDRSharp.ADSBPlugin" />
	  to the <sharpPlugins> section in the SDRSharp.exe.config
	- start SDRSharp again

USAGE
	- select "Configure" and choose 2.0 MSP as Samplerate
	  (because we need to oversample the 1Mbit signal by the factor of 2)
	- tune to 1090 MHz
	- Hit start
	- Connect e.g. ADSBscope or other compatible software to local TCP port 47806
	  or share the data with e.g. sdrsharp.com and connect ADSBscope or other software to them
	- have fun :-)

USAGE with ADSBscope
	- Start it ;-)
	- In the menu choose 
		   "other"
		   "Network"
		   "Network Setup"

	- In the Network setup window click on
		   "ADSB#"
		   "local"
		and finally
		   "Close"

	If ADSB# or my plugin is running you can select
		   "other"
		   "Network"
		   "RAW-data Client active"

	or do it with the icon.

	Logging can be activated/deactivated by clicking in the textbox (top right)



TROUBLESHOOTING:
	- if you cannot select 2.0 MSP as samplerate, please replace the SDRSharp.RTLSDR.dll
	  with the version in this zip file

Greets 

		Darkscout

Mailfang@gmx.de



HISTORY
	Version 3
		- Internal datatype fix
		- Added Buffer, Framedrop info to GUI
	Version 2
		- first real release to mailinglist