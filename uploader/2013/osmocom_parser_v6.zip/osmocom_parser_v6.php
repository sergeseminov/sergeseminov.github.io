<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
  <meta name="robots" content="none">
  <meta name="robots" content="noindex,nofollow">
  <meta name="robots" content="noarchive">
  <meta content="text/html; charset=windows-1251" http-equiv="Content-Type">
  <title>Dominique's Osmocom Parser v.6 &copy; 10.2013</title>
  <style>
body {
border:0;
margin-top: 0px;
margin-left: 0px;
}
td, p, input, form {
  font-family: Verdana, Arial, Helvetica, sans-serif;
  font-size: xx-small;
  font-weight: normal;
  color: #008080;
  </style>
</head>
<body style="background-color: rgb(205, 205, 205);" text="#008080" alink="#800000" link="#009090" vlink="#606060">
<center>
<br>

<?php

  $filename = '';
  $filepath = '';
  $filetype = '';

  if(isset($_FILES['ufile']) &&
      $_FILES['ufile']['error'] != 4)
  {
	if($_FILES['ufile']['error'] != 1 &&
        $_FILES['ufile']['error'] != 0)
	{
	  $error = $_FILES['ufile']['error'];
	  $errors []= '������: ���� �� ��������.'.
                    ' ��� ������: ' . $error;
	}
	else
    {
	  $filesize = $_FILES['ufile']['size'];
	  if($_FILES['ufile']['error'] == 1 ||
            $filesize > 3145728)
	  {
	   	$filesize = ($filesize != 0)?
            sprintf('(%.2f ��)' , $filesize / 1024): '';
	   	die('������: ������ ������������� ����� '.
            $filesize.' ������ ����������� (3 ��).');
	  }
	  else
	  {
	    $filename = $_FILES['ufile']['name'];
	   	$filepath = $_FILES['ufile']['tmp_name'];
	   	$filetype = $_FILES['ufile']['type'];

$txt_file = file_get_contents($filepath);
$rows = explode("\n\n", $txt_file);
echo '<font face="Arial"><font size="4"><br><b>Found Stations:</b></font><br><br>';
echo '<table border="1" cellpadding="1" cellspacing="4">';
echo '  <tbody>';
echo '    <tr>';
echo '     <td><p align="center"><b>No.</b></p></td>';
echo '     <td><p align="center"><b>ARI Class</b></p></td>';
echo '     <td><p align="center"><b>RFPI</b></p></td>';
echo '     <td><p align="center"><b>Level</b></p></td>';
echo '     <td><p align="center"><b>MAC Layer</b></p></td>';
echo '     <td><p align="center"><b>Ext MAC Layer</b></p></td>';
echo '     <td><p align="center"><b>Ext MAC Layer 2</b></p></td>';
echo '     <td><p align="center"><b>Higher Layer</b></p></td>';
echo '     <td><p align="center"><b>Ext Higher Layer</b></p></td>';
echo '     <td><p align="center"><b>Ext Higher Layer 2</b></p></td>';
echo '    </tr>';
foreach($rows as $row => $data)
{
    echo '<tr><td>';
    $row_data = explode(': ', $data);
    $station[$row]['no'] = $row_data[0];
    echo $station[$row]['no'] . '</td>';
    $station[$row]['ariclass'] = mb_substr($row_data[4],0,-4);
    if ($station[$row]['ariclass'] == "class A (residential)") {
    $station[$row]['emc'] = mb_substr($row_data[5],0,-4);
    } elseif ($station[$row]['ariclass'] == "class B (private multiple cell)") {
    $station[$row]['eic'] = mb_substr($row_data[5],0,-4);
    } elseif ($station[$row]['ariclass'] == "class C (public)") {
    $station[$row]['poc'] = mb_substr($row_data[5],0,-4);
    } elseif ($station[$row]['ariclass'] == "class D (public GSM)") {
    $station[$row]['gop'] = mb_substr($row_data[5],0,-4);
    }
    $station[$row]['fpn'] = mb_substr($row_data[6],0,-4);
    if ($station[$row]['ariclass'] == "class A (residential)") {
    $station[$row]['rfpi'] = '0'.$station[$row]['emc'];
    $fpn = base_convert($station[$row]['fpn'], 16, 10);
    $fpn_hex = base_convert(intval($fpn/2), 10, 16);
    while (strlen($fpn_hex)<4) {
    $fpn_hex = '0'.$fpn_hex;
    }
    $station[$row]['rfpi'] = $station[$row]['rfpi'].$fpn_hex;
    if ($fpn/2 == ceil($fpn/2)) {
    $station[$row]['rfpi'] = $station[$row]['rfpi'].'0';
    } else {
    $station[$row]['rfpi'] = $station[$row]['rfpi'].'8';
    }
    }
    if ($station[$row]['ariclass'] == "class A (residential)") {
    $station[$row]['rpn'] = mb_substr($row_data[7],0,1);
    } elseif ($station[$row]['ariclass'] == "class B (private multiple cell)") {
    $station[$row]['fps'] = mb_substr($row_data[7],0,-4);
    } elseif ($station[$row]['ariclass'] == "class C (public)") {
    $station[$row]['fps'] = mb_substr($row_data[7],0,-4);
    } elseif ($station[$row]['ariclass'] == "class D (public GSM)") {
    $station[$row]['rpn'] = mb_substr($row_data[7],0,1);
    }
    if ($station[$row]['ariclass'] == "class A (residential)") {
    $cell_data2 = explode(chr(9), $row_data[8]);
    $station[$row]['slevel'] = $cell_data2[0];
    } elseif ($station[$row]['ariclass'] == "class B (private multiple cell)") {
    $cell_data2 = "";
    $station[$row]['rpn'] = mb_substr($row_data[8],0,1);
    } elseif ($station[$row]['ariclass'] == "class C (public)") {
    $cell_data2 = "";
    $station[$row]['rpn'] = mb_substr($row_data[8],0,1);
    } elseif ($station[$row]['ariclass'] == "class D (public GSM)") {
    $cell_data2 = explode(chr(9), $row_data[8]);
    $station[$row]['slevel'] = $cell_data2[0];
    }
    if ($station[$row]['ariclass'] == "class A (residential)") {
     $cell_data = explode(chr(9), $row_data[9]);
     switch ($cell_data2[1]) {
      case "MAC layer capabilities":
      $station[$row]['mlayercap'] = $cell_data[0];
      break;
      case "Extended MAC layer capabilities":
      $station[$row]['extmlayercap'] = $cell_data[0];
      break;
      case "Extended MAC layer capabilities 2":
      $station[$row]['extmlayercap2'] = $cell_data[0];
      break;
      case "Higher layer capabilities":
      $station[$row]['hlayercap'] = $cell_data[0];
      break;
      case "Extended higher layer capabilities":
      $station[$row]['exthlayercap'] = $cell_data[0];
      break;
      case "Extended higher layer capabilities 2":
      $station[$row]['exthlayercap2'] = $cell_data[0];
      break;
     }
    } elseif ($station[$row]['ariclass'] == "class B (private multiple cell)") {
    $cell_data = explode(chr(9), $row_data[9]);
    $station[$row]['slevel'] = $cell_data[0];
    } elseif ($station[$row]['ariclass'] == "class C (public)") {
    $cell_data = explode(chr(9), $row_data[9]);
    $station[$row]['slevel'] = $cell_data[0];
    } elseif ($station[$row]['ariclass'] == "class D (public GSM)") {
    $cell_data = explode(chr(9), $row_data[9]);
    if ($cell_data[0]) {
    $station[$row]['mlayercap'] = $cell_data[0];
    }
    }
    $cell_data2 = explode(chr(9), $row_data[10]);
    switch ($cell_data[1]) {
     case "MAC layer capabilities":
     $station[$row]['mlayercap'] = $cell_data2[0];
     break;
     case "Extended MAC layer capabilities":
     $station[$row]['extmlayercap'] = $cell_data2[0];
     break;
     case "Extended MAC layer capabilities 2":
     $station[$row]['extmlayercap2'] = $cell_data2[0];
     break;
     case "Higher layer capabilities":
     $station[$row]['hlayercap'] = $cell_data2[0];
     break;
     case "Extended higher layer capabilities":
     $station[$row]['exthlayercap'] = $cell_data2[0];
     break;
     case "Extended higher layer capabilities 2":
     $station[$row]['exthlayercap2'] = $cell_data2[0];
     break;
     default:
     $cell_data2 = "";
    }
    $cell_data = explode(chr(9), $row_data[11]);
    switch ($cell_data2[1]) {
     case "MAC layer capabilities":
     $station[$row]['mlayercap'] = $cell_data[0];
     break;
     case "Extended MAC layer capabilities":
     $station[$row]['extmlayercap'] = $cell_data[0];
     break;
     case "Extended MAC layer capabilities 2":
     $station[$row]['extmlayercap2'] = $cell_data[0];
     break;
     case "Higher layer capabilities":
     $station[$row]['hlayercap'] = $cell_data[0];
     break;
     case "Extended higher layer capabilities":
     $station[$row]['exthlayercap'] = $cell_data[0];
     break;
     case "Extended higher layer capabilities 2":
     $station[$row]['exthlayercap2'] = $cell_data[0];
     break;
     default:
     $cell_data = "";
    }
    $cell_data2 = explode(chr(9), $row_data[12]);
    switch ($cell_data[1]) {
     case "MAC layer capabilities":
     $station[$row]['mlayercap'] = $cell_data2[0];
     break;
     case "Extended MAC layer capabilities":
     $station[$row]['extmlayercap'] = $cell_data2[0];
     break;
     case "Extended MAC layer capabilities 2":
     $station[$row]['extmlayercap2'] = $cell_data2[0];
     break;
     case "Higher layer capabilities":
     $station[$row]['hlayercap'] = $cell_data2[0];
     break;
     case "Extended higher layer capabilities":
     $station[$row]['exthlayercap'] = $cell_data2[0];
     break;
     case "Extended higher layer capabilities 2":
     $station[$row]['exthlayercap2'] = $cell_data2[0];
     break;
     default:
     $cell_data2 = "";
    }
    $cell_data = explode(chr(9), $row_data[13]);
    switch ($cell_data2[1]) {
     case "MAC layer capabilities":
     $station[$row]['mlayercap'] = $cell_data[0];
     break;
     case "Extended MAC layer capabilities":
     $station[$row]['extmlayercap'] = $cell_data[0];
     break;
     case "Extended MAC layer capabilities 2":
     $station[$row]['extmlayercap2'] = $cell_data[0];
     break;
     case "Higher layer capabilities":
     $station[$row]['hlayercap'] = $cell_data[0];
     break;
     case "Extended higher layer capabilities":
     $station[$row]['exthlayercap'] = $cell_data[0];
     break;
     case "Extended higher layer capabilities 2":
     $station[$row]['exthlayercap2'] = $cell_data[0];
     break;
     default:
     $cell_data = "";
    }
    echo '<td>' .$station[$row]['ariclass']. '</td>';
    echo '<td>' .$station[$row]['rfpi']. '</td>';
    echo '<td>' .$station[$row]['slevel']. '</td>';
    echo '<td>' .$station[$row]['mlayercap']. '</td>';
    echo '<td>' .$station[$row]['extmlayercap']. '</td>';
    echo '<td>' .$station[$row]['extmlayercap2']. '</td>';
    echo '<td>' .$station[$row]['hlayercap']. '</td>';
    echo '<td>' .$station[$row]['exthlayercap']. '</td>';
    echo '<td>' .$station[$row]['exthlayercap2']. '</td>';
    echo '</tr>';
}
	  }
	}
  } else {
echo '<form action="osmocom_parse6.php" method="post" enctype="multipart/form-data">';
echo '�������� ���� ��� ��������: <input type="file" name="ufile" />&nbsp;<input type="submit" name="send" value="���������!" />';
echo '</form>';
}

?>
</tbody>
</table>
</center>
</body>
</html>